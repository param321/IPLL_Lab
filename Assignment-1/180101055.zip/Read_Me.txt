-> input.txt is attached and is input to our source code
-> on running source code will generate two files intermediate.txt and object.txt which are intermediate flie and object code file respectively
-> To run the source code
    Command To compile the source code : g++ 180101055_Assign01.cpp
    Command to execute : ./a.out